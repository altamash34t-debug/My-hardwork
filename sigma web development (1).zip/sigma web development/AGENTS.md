# AI Agent Instructions

## Project overview
- Small static web project with a single entry point: `index.html`
- No existing build, test, or framework conventions in the workspace
- Best treated as a browser-focused HTML/CSS/JavaScript project

## What agents should know
- Keep changes minimal and file-based unless the user asks for a larger refactor
- Prefer adding separate `styles.css` and `script.js` files when introducing CSS or JavaScript
- Avoid inventing backend or build systems unless explicitly requested

## Focus area: mouse interactions
- The current project is a good fit for mouse-driven UI enhancements
- When asked to work on `mouse`, prioritize hover effects, pointer events, drag/drop, click handling, and accessible interactions
- Keep behavior compatible with standard browser APIs and desktop mouse usage

## Agent guidance
- If adding JavaScript, attach it via `script.js` and add only the code needed for the requested feature
- If adding styles, use `styles.css` and avoid inline styling unless the user requests a quick prototype
- Preserve the simple structure and avoid adding dependencies unless explicitly asked

## When to ask the user
- If a requested change needs more detail about the mouse behavior or UI design
- If there is any uncertainty about the intended interaction model

## Notes
- No documentation files exist yet beyond the root HTML file
- If the project grows, update this file or add `.github/copilot-instructions.md` to reflect new conventions
